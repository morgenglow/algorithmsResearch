func binarySearch(array: [Int], searchValue: Int) -> Int? {
    var lowerIndex = 0
    var upperIndex = array.count - 1
    
    while (true) {
        let midIndex = (lowerIndex + upperIndex)/2
        if array[midIndex] == searchValue {
            return midIndex
        }
        else if (lowerIndex > upperIndex) {
                return nil
            }
        else {
            if (array[midIndex] > searchValue){
                upperIndex = midIndex - 1
            }
            else {
                lowerIndex = midIndex + 1
            }
        }
    }
}

let array = [1, 2, 4, 5, 6, 7, 8, 9, 10]
binarySearch(array: array, searchValue: 10)

//  Задача
//  
//  Зоро пошел покупать мечи в магазине мечей. Магазин мечей имеет N мечей. Цены каждого меча лежат в массиве A. Цена меча это A[i]. Теперь у Зоро есть кол-во вопросов R в и в каждом вопросе Q  он хочет знать номер и цену меча у которого цена меньше чем данная сумма М.
//  
//  Ограничения массивов и параметров:
//  
//  1 ≤ N ≤ 10^5   (10 в 5 степени)
//  1 ≤ A[i] ≤ 10^9 
//  1 ≤ R ≤ 10^5
//  1 ≤ M ≤ 10^5
//  
//  Значения:
//  
//  N = 5
//  A = [1,6,4,10,5]
//  R = 4
//  
//  Q1 = 2
//  Q2 = 3
//  Q3 = 5
//  Q4 = 11
//  
//  После каждого вопроса выводить номер меча и цену в вывод

