
class ListNode {
    var value: Int
    var next: ListNode?
    init(value: Int, next: ListNode?){
        self.value = value
        self.next = next
    }
}

let thirdNode = ListNode(value: 5, next: nil)
let secondNode = ListNode(value: 4, next: thirdNode)
let oneNode = ListNode(value: 3, next: secondNode)



func printList (head: ListNode?) {
    var currentNode = head
    while currentNode != nil {
        print ("\(currentNode!.value) -> ")
        currentNode = currentNode?.next
    }
}

printList(head: oneNode)

func mergeTwoLists(list1: ListNode?, list2: ListNode?) -> ListNode?{
    guard list1 != nil else {return list2}
    guard list2 != nil else {return list1}
    
    let dummyHead: ListNode = ListNode(value: 0, next: nil) 
    var l1 = list1, l2 = list 2
    var endOfSortedList: ListNode? = dummyHead //заполнитель нового связного списка
    
    while l1 != nil & l2 != nil {
        if l1!.value <= l2!.value {
            endOfSortedList!.next = l1
            l1 = l1!.next
        }
        else {
            endOfSortedList!.next = l2
            l2 = l2!.next
        }
        endOfSortedList = endOfSortedList?.next
    }
    endOfSortedList?.next = l1 == nil? l2:l1
    return dummyHead.next
}
