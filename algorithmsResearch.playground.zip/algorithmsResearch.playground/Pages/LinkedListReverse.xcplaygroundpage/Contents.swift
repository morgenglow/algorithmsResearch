
class ListNode {
    var value: Int
    var next: ListNode?
    init(value: Int, next: ListNode?){
        self.value = value
        self.next = next
    }
}

let thirdNode = ListNode(value: 5, next: nil)
let secondNode = ListNode(value: 4, next: thirdNode)
let oneNode = ListNode(value: 3, next: secondNode)



func printList (head: ListNode?) {
    var currentNode = head
    while currentNode != nil {
        print ("\(currentNode!.value) -> ")
        currentNode = currentNode?.next
    }
}

printList(head: oneNode)

func reverseList(head: ListNode?) -> ListNode?{
    var currentNode = head
    var next: ListNode?
    var prev: ListNode?
    
    while currentNode != nil {
        next = currentNode?.next
        currentNode?.next = prev
        prev = currentNode
        currentNode = next
    }
    return prev
}
