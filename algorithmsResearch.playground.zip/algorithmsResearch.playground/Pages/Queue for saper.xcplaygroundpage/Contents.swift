//FIFO
//[]
//[] <- 1
//[1] <- 2
//[1, 2] ->
//[2]

struct Queue<T>{
    private var list = LinkedList<T>()
    
    mutating func enqueue(element: T){
        mutating list.appent(element)
    }
    
    mutating func dequeue() -> T? {
        quard !list.isEmpty, let element = list.first else {return nil}
        list.remove(head)
        return element.value
    }
}

var queue = Queue<Int>()

