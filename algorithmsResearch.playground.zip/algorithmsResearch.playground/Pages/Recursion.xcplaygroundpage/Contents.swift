// n-й член последовательности фиббоначи
//1 1 2 3 5 8 13 ...

func fibbonachi(n: Int) -> Int {
    var first = 1
    var second = 1
    
    for _ in 0..<n - 2 {
        var next = first + second
        first = second
        second = next
    }
    return second
}

fibbonachi(n: 4)

func fibbonnachiRec(n: Int) -> Int {
    guard n > 1 else { return n }
    return fibbonnachiRec(n: n-1) + fibbonnachiRec(n: n-2)
}

func fibbonachiRecShort(n: Int) -> Int {
    return n > 1 ? fibbonachiRecShort(n: n-1) + fibbonachiRecShort(n: n-2) : n
}
fibbonachiRecShort(n: 5)
