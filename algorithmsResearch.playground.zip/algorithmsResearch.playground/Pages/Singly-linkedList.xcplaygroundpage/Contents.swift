class Node<T: Equatable> {
    var item: T
    var next: Node<T>?
    
    init(element: T){
        item = element
    }
    func add(newItem: T){
        if let nextNode = next{
            nextNode.add(newItem: newItem)
        }
        else {
            next = Node<T>(element: newItem)
        }
    }
    
}

class LinkedList<T: Equatable>{
    var head: Node<T>?
    
    func add(item: T){
        if head != nil {
            head!.add(newItem: item)
        }
        else {
            head = Node(element: item)
        }
    }
    
    func remove(item: T){
        if head != nil {
            if head!.item == item{
                head = head!.next
            }
            else {
                var current = head
                var prev = head
                while current!.next != nil && current!.item != item {
                    prev = current
                    current = current!.next
                }
                if let deleted = current {
                    if deleted.item == item {
                        if let nexter = deleted.next {
                            prev?.next = nexter
                            deleted.next = nil
                        }
                        else {
                            prev?.next = nil
                        }
                    }
                }
            }
        }
    }
    var size: Int {
        var current = head
        var counter = 0
        while current != nil {
            counter += 1
            current = current?.next
        }
        return counter
    }
}

extension LinkedList {
    func print() -> String{
        var str = ""
        var current = head
        while current != nil {
            str += "\(current!.item) => "
            current = current?.next
        }
        return str
    }
}


