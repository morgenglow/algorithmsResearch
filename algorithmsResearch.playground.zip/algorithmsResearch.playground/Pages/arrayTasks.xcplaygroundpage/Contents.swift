//  Дан массив целых чисел и объект типа Int. Верните значение двух чисел массива которые в сумме дают значение объекта.
// Решение может быть только одно и элементы в массиве не повторяются. Если пара не найдена - вернуть пустой массив.

//  1/ внимательно читаем/ слушаем условие задачи
//  2/ придумываем уточнющие вопросы
//  3/ рисуем примеры, лучше парочку
//  4/ придумываем решение в лоб и оцениваем сложность
//  5/ придумываем более оптимальное решение
//  6/ тестируем код в тетрадке на новом примере
//  7/ переписываем код в IDE

class Solution {
    func twoSum(array: [Int], target: Int) -> [Int] {
        var resultArray: [Int] = []
        var dictionary: [Int : Int] = [:]
        for (indexArray, valueArray) in array.enumerated() {
            if let index = dictionary[target - valueArray]{
                resultArray.append(index)
                resultArray.append(indexArray)
                return resultArray
            }
            dictionary[valueArray] = indexArray
        }
        return resultArray
    }
}

let example = Solution()
example.twoSum(array: [4, 6, 7, 9, 8, 12], target: 16)

//  удалить дубликаты в отсортированном массиве
class SolutionSort {
    func removeDuplicates(array: inout [Int]) -> Int {
        var last: Int?
        var index: Int = 0
        while index < array.count {
            if array[index] == last {
                array.remove(at: index)
            }
            else {
                last = array[index]
                index += 1
            }
        }
        return array.count
    }
}

let example2 = SolutionSort()
var array = [0, 0, 2, 4, 5, 6, 6, 8]
example2.removeDuplicates(array: &array)
print (array)

//на вход подается массив, в этом массиве нужно найти такой подмассив, который, если вы отсортируете в порядке возрастания, отсортирует весь массив в порядке возрастания
    func findUnsortedArray(array: [Int]) -> Int {
    var n = array.count
    var maxNum = array[0]
    var end = 0
    var minNum = array[n - 1]
    var start = 1
    for (index, currentItem) in array.enumerated() {
        maxNum = max(maxNum, currentItem)
            if currentItem < maxNum {
                end = index
                print(end)
            }
        }
    for (index, currentItem) in array.enumerated().reversed() {
        minNum = min(minNum, currentItem) 
            if currentItem > minNum {
                start = index
                print(start)
            }
    }
    return end - start + 1
    }

findUnsortedArray(array: [1, 3, 4, 3, 6])
findUnsortedArray(array: [10, 3, 4, 3, 6])
    
// две строки с 1 одним отличающимся символом

//две строки одной длины
func isOneSameLength (firstString: String, secondString: String) -> Bool {
    var counterDifferent = 0
    for i in 0...firstString.count-1 {
        let indexFirst = firstString.index(firstString.startIndex, offsetBy: i)
        let indexSecond = secondString.index(secondString.startIndex, offsetBy: i)
        if firstString[indexFirst] != secondString[indexSecond] {
            counterDifferent += 1
            if counterDifferent>1{
                return false
            }
        }
    }
    return true
}

//две строки разной длины
func isOneDiffLength (firstString: String, secondString: String) -> Bool {
    var couterDifferent = 0
    var i = 0
    while i < secondString.count {
        let indexFirst = firstString.index(firstString.startIndex, offsetBy: i + couterDifferent)
        let indexSecond = secondString.index(secondString.startIndex, offsetBy: i)
        if firstString[indexFirst] == secondString[indexSecond] {
            i += 1
        }
        else {
            couterDifferent += 1
            if couterDifferent > 1{
                return false
            }
        }
    }
    return false
}

//общая функция
func isOneAway (firstString: String, secondString: String) -> Bool {
    if firstString.count-secondString.count >= 2 || secondString.count-firstString.count>=2 {
        return false
    } else if firstString.count == secondString.count {
        return isOneSameLength(firstString: firstString, secondString: secondString)
    }
    else if firstString.count > secondString.count{
        return isOneDiffLength(firstString: firstString, secondString: secondString)
    }
    else {
        return isOneDiffLength(firstString: secondString, secondString: firstString)
    }
}
