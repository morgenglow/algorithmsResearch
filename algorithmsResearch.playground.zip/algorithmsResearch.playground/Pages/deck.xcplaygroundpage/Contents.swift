//двусторонняя очередь 
//можно рассматривать как два стека
//addFirst
//addLast
//removeFirst
//removeLast
//head
//tail
