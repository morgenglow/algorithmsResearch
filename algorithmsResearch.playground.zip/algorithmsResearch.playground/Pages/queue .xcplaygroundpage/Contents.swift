//очередь FIFO - первым зашел первым вышел (очереди задач)

struct Queue<T> {
    var container = [T]()
    
    // проверка пустая ли очередь
    var isEmpty: Bool {
        get{
            return container.isEmpty
        }
    }
    
    // возвращает размер очереди
    var size: Int {
        get{
            return container.count
        }
    }
    
    // первый элемент очереди
    var head: T?{
        get{
            return container.first
        }
    }
    
    // последний элемент очереди 
    var tail: T?{
        get{
            return container.last
        }
    }
    
    // добавление в очередь - в хвост
    mutating func enqueue(elem: T) {
        container.append(elem)
    }
    
    // забрать из очереди - из головы
    mutating func dequeue() -> T? {
        if !isEmpty {
            return container.remove(at: 0)
        }
        return nil
    }
}

var queue = Queue<Int>()
queue.isEmpty
queue.enqueue(elem: 10)
queue.enqueue(elem: 6)
queue.enqueue(elem: 9)
queue.enqueue(elem: 0)
queue.head
queue.dequeue()
queue.tail
queue.size
queue.head


