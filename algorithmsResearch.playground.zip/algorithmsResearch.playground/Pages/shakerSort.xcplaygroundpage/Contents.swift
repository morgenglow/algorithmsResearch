// Шейкерная сортировка массива целых чисел

func shakerSorting (array: [Int]) -> [Int]{
    var sortedArray = array
    var leftIndex = 0
    var rightIndex = sortedArray.count-1
    var flag: Bool //флаг проверки наличия перемещений
    
    //проверяем пока границы не замкнутся
    while leftIndex < rightIndex {
        flag = false
        
        //слева направо
        for i in (leftIndex..<rightIndex){
            if sortedArray[i] > sortedArray[i+1] {
                sortedArray.swapAt(i+1, i)
                flag = true
            }
        }
        
        rightIndex -= 1 //сдвигаем правый индекс конца на один, чтобы не проверять последний элемент
        if flag == false {break}
        
        //справа налево
        for i in (leftIndex..<rightIndex).reversed(){
            if sortedArray[i] > sortedArray[i+1] {
                sortedArray.swapAt(i, i+1)
                flag = true
            }
        }
        
        rightIndex -= 1 //сдвигаем левый индекс наала на один, чтобы не проверять первый элемент
        leftIndex += 1
        if flag == false {break}
    }
    return sortedArray
}

let array = [10, 20, 43, 9, 1, -9, 17]
print (shakerSorting(array: array))

