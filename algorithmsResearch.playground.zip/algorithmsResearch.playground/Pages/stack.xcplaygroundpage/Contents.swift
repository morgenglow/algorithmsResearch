//реализация стека LIFO - last in first out (навигация по страницам)

struct Stack<T> {
    var container = [T]()
    
    //проверка на пустоту
    var isEmpty: Bool{
        get{
            return container.isEmpty
        }
    }
    
    //узнать верхний элемент
    var top: T?{
        get{
            return container.last
        }
    }
    
    //узнаем размер стека
    var size: Int {
        get{
            container.count
        }
    }
    
    //вставить элемент
    mutating func push(element: T){
        container.append(element)
    }
    
    //забрать вершину стека
    mutating func pop() -> T? {
        if !isEmpty {
            return container.removeLast()
        }
        return nil
    }
    
}

var stack = Stack<String>()
stack.isEmpty
stack.pop()
stack.push(element: "a")
stack.push(element: "b")
stack.push(element: "c")
stack.size
stack.pop()
stack.top
