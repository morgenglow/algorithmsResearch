
// написать функцию, которая переворачивает строку изменения в текущем массиве о(N)
//  г о а т -> т о а г
class reverseArray {
    func reverseString(string: inout [Character]) {
        var last = string.count - 1
        var first: Int = 0
        while first < last {
            let temp = string[first]
            string[first] = string[last]
            string[last] = temp
            first += 1
            last -= 1
        }
    }
}
